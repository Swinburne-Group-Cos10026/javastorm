<?php
	$host = "localhost";
	$user = "kwen"; // your user name
	$pwd = "Loey5312126@"; // your password (date of birth ddmmyy unless changed)
	$sql_db = "COS10026"; // your database
?>
	
	
	