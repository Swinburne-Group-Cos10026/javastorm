<?php
define("HOST", "localhost:3307");
define("DATABASE", "assignmentjavastorm");
define("USERNAME", "root");
define("PASSWORD", "Mo!ConCho2003");
?>